package com.biblio.biblioteca.controller;

import com.biblio.biblioteca.model.Libro;
import com.biblio.biblioteca.repository.LibroRepository;
import com.biblio.biblioteca.service.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class LibroController {
    @Autowired
    private LibroService libroService;

    @GetMapping("/")
    public String viewHomePage(Model model){

        return findPaginated(1, "titulo", "asc", model);
    }

    @GetMapping("/libros")
    public ResponseEntity<List<Libro>>getAllLibros(){
        List<Libro> libros = libroService.getAllLibros();
              return new ResponseEntity<>(libros, HttpStatus.OK);
    }

    @GetMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable(value="pageNo") int pageNo,
                                @RequestParam("sortField") String sortField,
                                @RequestParam("sortDir") String sortDir,
                                Model model){
        int pageSize=4;
        Page<Libro> page = libroService.findPaginated(pageNo, pageSize, sortField, sortDir) ;
        List<Libro> listLibro=page.getContent();

        model.addAttribute("currentPage", pageNo);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ?
                "decs" : "asc");
        model.addAttribute("listLibro", listLibro);


        return "index";
    }

    /*
    @GetMapping("/page")
    public List<Libro> getPageOne()
    {
        // First page with 5 items
        Pageable paging = PageRequest.of(
                0, 5, Sort.by("user").ascending());
        Page<Libro> page = libroRepository.findAll(paging);
        // Retrieve the items
        return page.getContent();
    }*/

    @PostMapping("/save")
    public String saveCurso(@ModelAttribute("titulo") Libro l){
        this.libroService.saveLibro(l);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteLibro(@PathVariable(value="id") long id, Model model){
        this.libroService.deleteLibroById(id);
        return "redirect:/";
    }

    @GetMapping("/update/{id}")
    public String showFormUpdate(@PathVariable(value="id") long id, Model model){
        Libro libro = libroService.getLibroById(id);
        model.addAttribute("libro", libro);
        return "update_course";
    }

    @GetMapping("/add")
    public String showNewForm(Model model) {
        Libro l = new Libro();
        model.addAttribute("libro", l);
        return "libros";
    }
}
