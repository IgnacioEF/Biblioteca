package com.biblio.biblioteca.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="autor")
public class Autor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private String nombre;

    @Column
    private String nacionalidad;

    @Column
    private Date fechaNacimiento;

    @OneToMany(mappedBy="autor", targetEntity=Libro.class, cascade=CascadeType.ALL)
    @Column
    private Set<Libro> librosPublicados = new HashSet<>();
}
