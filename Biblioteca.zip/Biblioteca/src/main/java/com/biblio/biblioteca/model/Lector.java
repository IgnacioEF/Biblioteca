package com.biblio.biblioteca.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="lector")
public class Lector{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column
    String direccion;

    @Column
    String nombre;

    @Column
    String telefono;

    @Column
    @OneToMany(mappedBy="lector", targetEntity=Prestamo.class)
    private Set<Prestamo> prestamo = new HashSet<>();

    @JoinColumn
    @OneToOne(mappedBy="lector", targetEntity=Multa.class)
    private Multa multa;





}
