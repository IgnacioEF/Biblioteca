package com.biblio.biblioteca.service;

import com.biblio.biblioteca.model.Empleado;
import com.biblio.biblioteca.model.Lector;
import org.springframework.data.domain.Page;

import java.util.List;

public interface EmpleadoService{
    /*List<Empleado> getAllEmpleado();
    void saveCurso(Empleado empleado);
    Lector getCursoById(Long id);
    void deleteCursoById(Long id);
    Page<Empleado> findPaginated(int pageNum, int pageSize, String sortField, String sortDirection);*/
}