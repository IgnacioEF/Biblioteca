package com.biblio.biblioteca.model;

public enum EstadoCopia {
    PRESTADO, RETRASO, BIBLIOTECA,REPARACION;
}
