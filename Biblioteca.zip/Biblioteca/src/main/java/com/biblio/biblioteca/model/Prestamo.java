package com.biblio.biblioteca.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="prestamo")
public class Prestamo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column
    LocalDate inicio;

    @Column
    LocalDate fin;

    @JoinColumn
    @ManyToOne(fetch=FetchType.LAZY)
    private Lector lector;

    @JoinColumn
    @OneToOne(mappedBy="prestamo", targetEntity=Copia.class, cascade=CascadeType.ALL)
    private Copia copia;
}
