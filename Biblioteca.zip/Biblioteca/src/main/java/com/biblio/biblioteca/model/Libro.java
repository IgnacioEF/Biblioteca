package com.biblio.biblioteca.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="libro")
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long isbn;

    @Column
    private String titulo;

    @Column
    private TipoLibro tipo;

    @Column
    private String editorial;

    @Column
    private int anyo;

    @JoinColumn
    @ManyToOne(fetch=FetchType.LAZY)
    private Autor autor;

    @OneToMany(mappedBy="libro", targetEntity=Copia.class, cascade=CascadeType.ALL)
    @Column
    private Set<Copia> copia = new HashSet<>();
}
