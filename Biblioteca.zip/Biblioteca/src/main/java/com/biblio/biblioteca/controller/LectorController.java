package com.biblio.biblioteca.controller;

public class LectorController {
}
