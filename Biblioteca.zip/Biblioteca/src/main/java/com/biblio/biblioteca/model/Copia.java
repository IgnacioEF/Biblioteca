package com.biblio.biblioteca.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="copia")
public class Copia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private EstadoCopia estado;

    @JoinColumn
    @ManyToOne(fetch=FetchType.LAZY)
    private Libro libro;

    @JoinColumn
    @OneToOne
    private Prestamo prestamo;
}
