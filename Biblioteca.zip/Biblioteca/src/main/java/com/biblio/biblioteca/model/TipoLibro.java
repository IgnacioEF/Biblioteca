package com.biblio.biblioteca.model;

public enum TipoLibro {
    NOVELA, TEATRO, POESIA, ENSAYO;
}
