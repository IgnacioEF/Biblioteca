package com.biblio.biblioteca.controller;

public class EmpleadoController {
}
